package States.StanceState;

public class OnGround extends ModeState {
    private static OnGround instance = new OnGround();
    public static OnGround Instance(){return instance;}
}
