package States.AircraftState;

public class Damaged extends AircraftState{
    private static Damaged instance = new Damaged();
    public static Damaged Instance(){return instance;}
}
