package Enum;

public enum Altitude {
    LOW,
    MID,
    HIGH
}
