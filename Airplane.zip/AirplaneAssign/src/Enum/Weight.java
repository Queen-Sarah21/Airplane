package Enum;

public enum Weight {
    LIGHT, MIDDLE, HEAVY, SUPERHEAVY
}
