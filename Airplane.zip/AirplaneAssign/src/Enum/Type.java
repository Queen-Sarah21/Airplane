package Enum;

public enum Type {
    COMMERCIAL, MILITARY;
}
